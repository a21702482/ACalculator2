package com.example.acalculator

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.objecthunter.exp4j.Expression
import net.objecthunter.exp4j.ExpressionBuilder

class HistoryLogic{

    private val storage = ListStorage.getInstance()

    fun clickList(list: ArrayList<Operation>, indice: Int): ArrayList<Operation>{
        if(indice > storage.count())
        {
            list.removeAt(indice)
        }
        return list
    }
}