package com.example.acalculator

interface onDisplayChanged {

    fun onDisplayChanged(value: String?)
}