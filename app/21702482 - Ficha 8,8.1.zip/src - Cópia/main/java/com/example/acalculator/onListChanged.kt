package com.example.acalculator

interface onListChanged {

    fun onListChanged(value: ArrayList<Operation>)
}